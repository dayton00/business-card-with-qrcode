<?php 
  session_start(); 

  if (!isset($_SESSION['username']))
  if (!isset($_SESSION['state'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: ../login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: ../login.php");
  }
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>QR CODE</title>
    <link rel="stylesheet" type="text/css" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.19.1/ui/trumbowyg.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
       
    <body style="background-color:lightgray">
   <script src="https://cdn.jsdelivr.net/gh/manucaralmo/GlowCookies@3.1.8/src/glowCookies.min.js"></script>
<script>
    glowCookies.start('en', {
        style: 1,
        analytics: 'UA-196571800-1',
        policyLink: 'https://url.com/privacy.php'
    });
</script>
<div id="cookies-eu-banner" style="display: none;">
    By continuing to visit this site, you accept the use of cookies for statistical purposes.
    <a href="https://daytips.xyz/privacy.php" id="cookies-eu-more">Read more</a>
    <button id="cookies-eu-reject">Reject</button>
    <button id="cookies-eu-accept">Accept</button>
</div>
    </head>
  
    <style>
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-color: lightgray;
            width: 100%;
            padding: 20px;
    
        }

        .topnav {
            overflow: hidden;
            background-color: #D2691E;
            width: 100%;
        }

        .topnav a {
            float: left;
            display: block;
            color: #2f2f2;
            text-align: center;
            padding: 2px 20px;
            text-decoration: none;
            font-size: 24px;
            
        }

        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }

        .topnav a.active {
            background-color: #04AA6D;
            color: white;
        }

        .topnav .icon {
            display: none;
        }

        @media screen and (max-width: 600px) {
            .topnav a:not(:first-child) {
                display: none;
            }

            .topnav a.icon {
                float: right;
                display: block;
            }
        }

        @media screen and (max-width: 600px) {
            .topnav.responsive {
                position: relative;
            }

            .topnav.responsive .icon {
                position: absolute;
                right: 0;
                top: 0;
            }

            .topnav.responsive a {
                float: none;
                display: block;
                text-align: center;
            }
        }
        
        header {
            color: black;
            text-align: left;
            padding: 10px;
        }

        footer {
            background-color: black;
            color: white;
            clear: both;
            text-align: left;
            padding: 0px;
        }
        .float-child {
    width: 70%;
    float: left;
    padding: 30px;
    border: 10px ;
}
 .ads {
            float: left;
            width: 30%;
            padding: 5px;
        }

/* Media query for Android devices */
        @media screen and (max-width: 600px) {
            body {
                width: 250%;
            }
    </style>
</head>
<body>
    <header class="w3-container w3-teal">
        <h1>Business Cards</h1>
       
    </header>

    <div class="topnav" id="myTopnav">
       <!-- Existing navigation links -->
<!-- ... -->

<?php if (isset($_SESSION['username'])) : ?>
    <a href="index.php?logout='1'" style="color: red;">Logout</a>
    <a href="../../insert.php" style="color: black;">Create-Card</a>
    <a href="../editor.php" style="color: black;">Edit/Delete-Card</a>
    <a href="../download.php" style="color: black;">Download Card</a>
<?php else : ?>
    <a href="login.php" style="color: green;">Login</a>
    <a href="register.php" style="color: green;">Register</a>
<?php endif; ?>

        <a href="javascript:void(0);" class="icon" onclick="myFunction()"><i class="fa fa-bars"></i></a>
        <div style="padding-center: 16px">
            <h2>@www.daytips.xyz</h2> 
            <p>🌐@⚽</p>
        </div>
    </div>


    <script>
        function myFunction() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
            } else {
                x.className = "topnav";
            }
        } 
    </script>

    <footer>
        <!-- Footer content here -->
    </footer>
</body>
</html>
 </div>
   
           <!DOCTYPE html>
<html lang="en">
    <style>
      body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px; /* Add padding to all sides */
            background-color: #f0f0f0;
            display: flex;
            flex-wrap: wrap; /* Allow cards to wrap to the next line */
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
            min-height: 100vh; /* Ensure minimum height to fill the screen */
        }

.business-card {
    background-color: rgb(180, 107, 12);
    border-radius: 50px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    padding: 10px;
    text-align: center;
}


.card-header img {
    max-width: 100px;
    height: auto;
    margin: 10px;
}

.card-header h1 {
    font-size: 2rem;
    margin: 10px 0;
}

.card-header p {
    font-size: 2rem;
    color: #555;
}

.card-details p {
    font-size: 1.5rem;
    margin: 8px 0;
}

.card-details a {
    text-decoration: none;
    color: #007BFF;
    transition: color 0.3s ease;
}

.card-details a:hover {
    color: #0056b3;
}
            /* Add CSS styles specific to the business card */
            .business-card {
                width: 100%; /* Full width on all screens */
                max-width: 500px; /* Maximum width for larger screens */
                margin: 0 auto; /* Center the card horizontally */
                background-color: #808080;
                text-align: center;
                font-family: Arial, sans-serif;
                font-size: 16px;
                color: white;
                padding: 20px; /* Increase padding for better readability */
            }
            .card-header {
                margin-top: 20px;
            }
            .card-details {
                margin-top: 20px;
                padding: 10px;
                text-align: left;
            }
            /* Additional CSS for visual divider */
            .divider {
                width: 100%;
                border: 1px solid #BB7010;
            }

            /* Media query for screens smaller than 768px (typical for mobile) */
            @media (max-width: 768px) {
                .business-card {
                    max-width: 100%; /* Full width on small screens */
                }
                /* You can adjust font size or other styles for mobile here */
            }
        </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Business Card</title>
</head>
<body>
    <div class="business-card">
        <div class="card-header">
            <img src="img/icon@2x.png" alt="Your Company Logo">
            <h1>Your Name</h1>
             <h3>Your Job Title</h3>
             <p>Business Card Sample</p>
        </div>
        <div class="card-details">
            <p>Email: your.email@example.com</p>
            <p>Phone: +1 (123) 456-7890</p>
            <p>Website: www.yourwebsite.com</p>
            <img src="img/icon@2x.png" height="100 px" width="100px" aligh="left" alt="Your QR code">
            <img src="img/icon@2x.png" height="100 px" width="100px" aligh="right" alt="Your QR code">
            <img src="img/icon@2x.png" height="100 px" width="100px" aligh="right" alt="Your QR code">
             <img src="img/icon@2x.png" height="100 px" width="100px" aligh="right" alt="Your QR code">
        </div>
    </div>
</body>
</html>

</div>

</div>
</div>
  <p></p>
<div>

    </footer>
  </div>

</p>
 

</body>
</html>
 
 