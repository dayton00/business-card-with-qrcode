<?php
// Check if POST data "img" is set
if (isset($_POST["img"])) {
    // Open a file named "demoB.png" for writing
    $file = fopen("demoB.png", "w");
    
    // Split the POST data by comma to get the base64-encoded image data
    $data = explode(",", $_POST["img"]);
    
    // Decode the base64-encoded image data
    $data = base64_decode($data[1]);
    
    // Write the decoded image data to the file
    fwrite($file, $data);
    
    // Close the file
    fclose($file);
    
    // Output "OK" to indicate success
    echo "OK";
} else {
    // If "img" POST data is not set, output an error message
    echo "Error: POST data 'img' not received.";
}
?>
