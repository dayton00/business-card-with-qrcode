<?php 
  session_start(); 

  // Check if the user is not logged in
  if (!isset($_SESSION['username']) && !isset($_SESSION['state'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }

  // Check if the user clicked the logout link
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .form-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            padding: 20px;
            text-align: center;
            width: 300px;
        }

        .form-container label {
            display: block;
            margin-bottom: 10px;
            text-align: left;
        }

        .form-container input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-container input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-container input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
    <title>Business Card</title>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1>Add a Business Card</h1>
            
    	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
            <a href="admin/editor.php" class="button">Edit/Delete Card</a>
            <form method="post" action="">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required><br>

                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required><br>

                <label for="email">Email:</label>
                <input type="text" id="email" name="email" required><br>

                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" required><br>

                <label for="website">Website:</label>
                <input type="text" id="website" name="website" required><br>

                <input type="submit" name="submit" value="Create a Card">
            </form>
        </div>
    </div>
</body>
</html>

<?php
// Database connection details
require_once('connect.php');

// Check if a session is already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_POST['name'])) {
    $name = $_POST['name'];
    $title = $_POST['title'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $website = $_POST['website'];

    // Insert data into the card table
    $sql = "INSERT INTO card (`name`, `title`, `email`, `phone`, `website`)
            VALUES ('$name', '$title', '$email', '$phone', '$website')";
    if (mysqli_query($conn, $sql)) {
    // Get the ID of the inserted record
    $insertedId = mysqli_insert_id($conn);

    // Generate QR code using the inserted data
    $qrCodeData = "Name: $name\nTitle: $title\nEmail: $email\nPhone: $phone\nWebsite: $website";
    $qrCodeImage = 'qrcodes/' . $insertedId . '.png'; // QR code image filename

    // Generate and save the QR code image
    require_once 'phpqrcode/qrlib.php';
    QRcode::png($qrCodeData, $qrCodeImage);

    // Add the custom URL to the image URL
    $customImageUrl = 'daytips.xyz/qr/admin/qrcodes/' . basename($qrCodeImage);

    // Update the database with the custom image URL
    $updateSql = "UPDATE card SET qrcode = '$customImageUrl' WHERE id = $insertedId";
    mysqli_query($conn, $updateSql);

    // Display a JavaScript notification
   echo <<<HTML
    <script>
        alert("New record created successfully!");
        window.location.href = "index.php"; // Redirect to home.php
    </script>
HTML;
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}

mysqli_close($conn);
?>