<?php
// Database connection details
require_once('connect.php');

// Check if a session is already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit;
}

// Initialize variables
$searchEmail = "";
$matchingCards = [];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the email from the form
    $searchEmail = $_POST["email"];

    // Define an SQL query to search for cards with the provided email
    $sql = "SELECT * FROM card WHERE email = '$searchEmail'";
    $result = $conn->query($sql);

    // Check if there are results
    if ($result === false) {
        echo "Error executing query: " . $conn->error;
    } else {
        // Fetch matching cards and store them in an array
        while ($row = $result->fetch_assoc()) {
            $matchingCards[] = $row;
        }
    }
}

// Start the HTML document
echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Your CSS styles here */
    </style>
    <title>Search Business Cards</title>
</head>
<body>
    <!-- Search form -->
    <form method="POST" action="">
        <label for="email">Enter Email:</label>
        <input type="text" id="email" name="email" value="$searchEmail">
        <button type="submit">Search</button>
    </form>

    <!-- Display matching cards -->
    <div class="matching-cards">
HTML;

// Display matching cards if any were found
if (!empty($matchingCards)) {
    foreach ($matchingCards as $card) {
        // Extract card data
        $name = $card["name"];
        $title = $card["title"];
        $email = $card["email"];
        $phone = $card["phone"];
        $website = $card["website"];
        $id = $card["id"]; // Get the ID of the card

        // Define the QR code image URL based on the ID
        $qrcodeUrl = "qrcodes/$id.png"; // Assumes the QR code image is named as "ID.png" in the "qrcodes" directory

        // Display the matching card
        echo <<<HTML
        <div class="business-card">
            <!-- Card content goes here -->
        </div>
HTML;
    }
} else {
    echo "<p>No matching cards found.</p>";
}

// Close the HTML document
echo <<<HTML
    </div>
</body>
</html>
HTML;

// Close the database connection
$conn->close();
?>
