<?php 
  session_start(); 

  // Check if the user is not logged in
  if (!isset($_SESSION['username']) && !isset($_SESSION['state'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }

  // Check if the user clicked the logout link
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<?php
require_once('connect.php');
session_start();
if(isset($_POST['submit'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $title = $_POST['title'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $website = $_POST['website'];
    $sql = "UPDATE card SET name='$name', `title`='$title', email='$email', phone='$phone', website='$website' WHERE id='$id'";
if (mysqli_query($conn, $sql)) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
} else {
    echo "No form data submitted";
}

mysqli_close($conn);
?>
