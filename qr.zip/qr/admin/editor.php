<?php 
  session_start(); 

  // Check if the user is not logged in
  if (!isset($_SESSION['username']) && !isset($_SESSION['state'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }

  // Check if the user clicked the logout link
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #BB7010;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }
    </style>
    <title>Edit/Delete Card</title>
</head>

<body>
    <?php
require_once('connect.php');
session_start();
    echo "<h1>Edit/Delete Card</h1>";

    $sql = 'SELECT * FROM card ORDER BY id DESC';
    $retval = mysqli_query($conn, $sql);
    echo "<table>" .
        "<tr>" .
        "<th>Card ID</th>" .
        "<th>Name</th>" .
        "<th>Title</th>" .
        "<th>Email</th>" .
        "<th>Phone</th>" .
        "<th>Website</th>" .
        "<th>Edit</th>" .
        "<th>Delete</th>" .
        "</tr>";

    if (mysqli_num_rows($retval) > 0) {
        while ($column = mysqli_fetch_assoc($retval)) {
            echo "<tr>" .
                "<td>{$column['id']}</td>" .
                "<td>{$column['name']}</td>" .
                "<td>{$column['title']}</td>" .
                "<td>{$column['email']}</td>" .
                "<td>{$column['phone']}</td>" .
                "<td>{$column['website']}</td>" .
                "<td><a href='edit.php?id={$column['id']}'>Edit</a></td>" .
                "<td><a href='delete.php?id={$column['id']}' onClick=\"return confirm('Are you sure you want to delete this record?')\">Delete</a></td>" .
                "</tr>";
        }
    } else {
        echo "<tr><td colspan='8'>0 results</td></tr>";
    }
    mysqli_close($conn);
    ?>
</body>

</html>
