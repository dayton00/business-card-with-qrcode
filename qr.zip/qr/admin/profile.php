<?php 
  session_start(); 

  // Check if the user is not logged in
  if (!isset($_SESSION['username']) && !isset($_SESSION['state'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }

  // Check if the user clicked the logout link
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<?php
require_once('connect.php');

// Check if a session is already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Fetch user data if logged in
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $user_query = "SELECT * FROM users WHERE username='$username' LIMIT 1";
    $user_result = mysqli_query($db, $user_query);
    $user = mysqli_fetch_assoc($user_result);
}

// Update user profile
if (isset($_POST['update_profile'])) {
    // Retrieve input values from the form
    $newUsername = mysqli_real_escape_string($db, $_POST['new_username']);
    $newEmail = mysqli_real_escape_string($db, $_POST['new_email']);

    // Validate input
    if (empty($newUsername)) {
        array_push($errors, "New username is required");
    }
    if (empty($newEmail)) {
        array_push($errors, "New email is required");
    }

    // If there are no errors, update the user's data
    if (count($errors) == 0) {
        $update_query = "UPDATE users SET username='$newUsername', email='$newEmail' WHERE username='$username'";
        mysqli_query($db, $update_query);

        // Update session data if username was changed
        if ($newUsername !== $username) {
            $_SESSION['username'] = $newUsername;
        }

        $_SESSION['success'] = "Profile updated successfully";
        header('location: profile.php');
    }
}

// Update user password
if (isset($_POST['update_password'])) {
    $newPassword = mysqli_real_escape_string($db, $_POST['new_password']);

    // Validate input
    if (empty($newPassword)) {
        array_push($errors, "New password is required");
    }

    // If there are no errors, update the user's password
    if (count($errors) == 0) {
        $encryptedPassword = sha1($newPassword); // Encrypt using SHA-1 (you should use a more secure hashing method)
        $update_query = "UPDATE users SET password='$encryptedPassword' WHERE username='$username'";
        mysqli_query($db, $update_query);

        $_SESSION['success'] = "Password updated successfully";
        header('location: profile.php');
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h2 {
            text-align: center;
            margin-top: 20px;
        }
        .container {
            width: 400px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .success {
            color: #008000;
            margin-bottom: 10px;
        }
        .error {
            color: #ff0000;
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="email"] {
            width: 50%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 3px;
            cursor: pointer;
        }
    </style>
    <title>User Profile</title>
</head>
<body>
    <h2>User Profile</h2>
    <?php if (isset($_SESSION['success'])) : ?>
        <div>
            <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
            ?>
        </div>
    <?php endif ?>

    <?php if (isset($user)) : ?>
    <form method="post" action="index.php">
        <?php include('errors.php'); ?>

        <label>New Username:</label>
        <input type="text" name="new_username" value="<?php echo $user['username']; ?>">

        <label>New Email:</label>
        <input type="email" name="new_email" value="<?php echo $user['email']; ?>">

        <button type="submit" name="update_profile">Update Profile</button>
    </form>

    <!-- New section for updating password -->
    <form method="post" action="index.php">
        <?php include('errors.php'); ?>

        <label>New Password:</label>
        <input type="password" name="new_password">

        <button type="submit" name="update_password">Change Password</button>
    </form>
<?php endif ?>

</body>
</html>
