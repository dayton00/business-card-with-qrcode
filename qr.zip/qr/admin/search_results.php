<?php 
  session_start(); 

  // Check if the user is not logged in
  if (!isset($_SESSION['username']) && !isset($_SESSION['state'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }

  // Check if the user clicked the logout link
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<?php
// Database connection details
require_once('connect.php');

// Check if a session is already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Define an SQL query to fetch data from the "card" table
$sql = "SELECT * FROM card";
$result = $conn->query($sql);

// Check if there are results
if ($result === false) {
    echo "Error executing query: " . $conn->error;
} else {
    // Start the HTML document
    echo <<<HTML
    <!DOCTYPE html>
    <html lang="en">
    <head>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js" integrity="sha512-BNaRQnYJYiPSqHHDb58B0yaPfCu+Wgds8Gp/gU33kqBtgNS4tSPHuGibyoeqMV/TJlSKda6FXzoEyYGjTe+vXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="styles.css">
        <style>
        button {
            background-color: #007BFF; /* Blue background color */
            color: white; /* Text color */
            border: none; /* Remove border */
            padding: 10px 20px; /* Add padding */
            font-size: 16px; /* Font size */
            cursor: pointer; /* Add a pointer cursor on hover */
            border-radius: 5px; /* Add rounded corners */
        }

        /* Add hover effect */
        button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
      body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px; /* Add padding to all sides */
            background-color: #f0f0f0;
            display: flex;
            flex-wrap: wrap; /* Allow cards to wrap to the next line */
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
            min-height: 100vh; /* Ensure minimum height to fill the screen */
        }

.business-card {
    background-color: rgb(180, 107, 12);
    border-radius: 50px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    padding: 10px;
    text-align: center;
}


.card-header img {
    max-width: 100px;
    height: auto;
    margin: 10px;
}

.card-header h1 {
    font-size: 2rem;
    margin: 10px 0;
}

.card-header p {
    font-size: 2rem;
    color: #555;
}

.card-details p {
    font-size: 1.5rem;
    margin: 8px 0;
}

.card-details a {
    text-decoration: none;
    color: #007BFF;
    transition: color 0.3s ease;
}

.card-details a:hover {
    color: #0056b3;
}
            /* Add CSS styles specific to the business card */
            .business-card {
                width: 100%; /* Full width on all screens */
                max-width: 500px; /* Maximum width for larger screens */
                margin: 0 auto; /* Center the card horizontally */
                background-color: #808080;
                text-align: center;
                font-family: Arial, sans-serif;
                font-size: 16px;
                color: white;
                padding: 20px; /* Increase padding for better readability */
            }
            .card-header {
                margin-top: 20px;
            }
            .card-details {
                margin-top: 20px;
                padding: 10px;
                text-align: left;
            }
            /* Additional CSS for visual divider */
            .divider {
                width: 100%;
                border: 1px solid #BB7010;
            }

            /* Media query for screens smaller than 768px (typical for mobile) */
            @media (max-width: 768px) {
                .business-card {
                    max-width: 100%; /* Full width on small screens */
                }
                /* You can adjust font size or other styles for mobile here */
            }
        </style>
        
        <title>Business Cards</title>
    </head>
    <body>
HTML;

    if (isset($_POST['email'])) {
        // Sanitize the email input
        $searchEmail = $conn->real_escape_string($_POST['email']);

        // Define an SQL query to search for cards with the given email
        $sql = "SELECT * FROM card WHERE email = '$searchEmail'";
        $result = $conn->query($sql);

        // Check if there are results
        if ($result === false) {
            echo "Error executing query: " . $conn->error;
        } else {
            // Loop through each row and display a separate card for each
            while ($row = $result->fetch_assoc()) {
                $name = $row["name"];
                $title = $row["title"];
                $email = $row["email"];
                $phone = $row["phone"];
                $website = $row["website"];
                $id = $row["id"]; // Get the ID of the card

                // Define the QR code image URL based on the ID
                $qrcodeUrl = "qrcodes/$id.png"; // Assumes the QR code image is named as "ID.png" in the "qrcodes" directory

                echo <<<HTML
                <div class="business-card">
                    <div class="card-header">
                        <img src="img/logo.png" alt="Your Company Logo">
                        <h1 style="color: black;"><em>$name</h1></em>
                        <h3>$title</h3>
                    </div>
                    <div class="card-details">
                        <p><b><strong>Email:</strong> <span style="color: black;">$email</p></b>
                        <p><strong><span style="text-align: center;">Phone:</strong> $phone</span></p>
                        <p><strong>Website:</strong> <span style="color: blue;">$website</span></p>
                        <div>
                        <img src="img/icon@2x.png" height="100px" width="200px" align="left" alt="Your QR Code">
                            <img src="$qrcodeUrl" height="100px" width="100px" align="right" alt="Your QR Code">
                        </div>
                    </div>
                </div>
                <hr class="divider"> <!-- Visual divider between cards -->
HTML;
            }
        }
    } else {
        // Display the form if the email was not provided for searching
        echo <<<HTML
        <h1>Search Business Cards by Email</h1>
        <form action="" method="POST">
            <label for="email">Enter Email:</label>
            <input type="email" id="email" name="email" required>
            <button type="submit">Search</button>
        </form>
HTML;
    }

    // End the HTML document
    echo <<<HTML
    <div> <form action="download.php">
        <button type="button" id="downloadButton">Download Cards</button>
    </form></div>
    </body>
    </html>
HTML;
}

// Close the database connection
$conn->close();
?>
<script>
// Function to capture and download the cards
function captureAndDownloadCards() {
  // Use HTML2Canvas to capture the content of the page
  html2canvas(document.body).then(canvas => {
    // Convert the captured content to a data URL
    const dataUrl = canvas.toDataURL("image/png");

    // Create a download link for the image
    const downloadLink = document.createElement("a");
    downloadLink.href = dataUrl;
    downloadLink.download = "business_cards.png"; // Set the filename
    downloadLink.click();
  });
}

// Add a click event listener to the button
document.getElementById("downloadButton").addEventListener("click", captureAndDownloadCards);
</script>
