<?php
$host = "sql110.epizy.com";
$user = "epiz_27978100";
$pass = "IGjAaxW6pzsC6";
$dbname = "epiz_27978100_card";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Could not connect: " . mysqli_connect_error());
}
?>
