<?php 
  session_start(); 

  // Check if the user is not logged in
  if (!isset($_SESSION['username']) && !isset($_SESSION['state'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }

  // Check if the user clicked the logout link
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<?php
require_once('connect.php');

// Check if a session is already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM card WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
}
else {
    echo "No card ID specified.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit cards</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>/* Add this CSS code to your existing style.css file or create a new one */

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f0f0f0;
}

h1 {
    font-size: 24px;
    text-align: center;
    margin-top: 20px;
}

form {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

label {
    display: block;
    font-size: 18px;
    margin-bottom: 8px;
}

input[type="text"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}

input[type="submit"] {
    background-color: #007BFF;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 18px;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}
</style>
<body>
    <h1>Edit cards</h1>
    <form method="post" action="update.php">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <label for="name">name:</label>
        <input type="text" name="name" value="<?php echo $row['name']; ?>"><br><br>
        <label for="title">title:</label>
        <input type="text" name="title" value="<?php echo $row['title']; ?>"><br><br>
        <label for="email">email:</label>
        <input type="text" name="email" value="<?php echo $row['email']; ?>"><br><br>
        <label for="phone">phone:</label>
        <input type="text" name="phone" value="<?php echo $row['phone']; ?>"><br><br>
        <label for="website">website:</label>
        <input type="text" name="website" value="<?php echo $row['website']; ?>"><br><br>
        <input type="submit" name="submit" value="Update">
    </form>
</body>
</html>

<?php
mysqli_close($conn);
?>
