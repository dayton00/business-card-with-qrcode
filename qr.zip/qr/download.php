<?php
// Define the path to the image file on your server
$imagePath = 'demoB.png'; // Replace with the actual path to your image

// Check if the image file exists
if (file_exists($imagePath)) {
    // Set the appropriate content type for image files (e.g., JPEG)
    header('Content-Type: image/png');

    // Set the Content-Disposition header to trigger a download with the original file name
    header('Content-Disposition: attachment; filename="' . basename($imagePath) . '"');

    // Read the image file and output its contents
    readfile($imagePath);

    // Exit to prevent any additional output
    exit;
} else {
    // Image file not found, you can handle this case as needed
    echo 'Image not found.';
}
?>
